function iniciarSesion() {
    $("form").submit(function (event) {
        event.preventDefault();

        var formData = {
            correo: $("#floatingInput").val(),
            contrasena: $("#floatingPassword").val()
        };

        $.ajax({
            type: "POST",
            url: "controllers/login.php",
            data: formData,
            dataType: "json",
            success: function (response) {
                if (response.success) {
                    // Muestra una notificación de éxito
                    alertify.success(response.message);
                    
                    // Redirige a la página de éxito después de un breve retraso
                    setTimeout(function () {
                        window.location.href = "inicio.php";
                    }, 1000);
                } else {
                    // Muestra una notificación de error
                    alertify.error(response.message);
                }
            },
            error: function () {
                alertify.error("Existe un error en el sistema favor comunicarse con soporte tecnico");
            }
        });
    });
}
function registrarUsuario() {
    // Obtener el formulario y sus elementos
    var form = document.getElementById("registroForm");
    var formData = new FormData(form);

    // Validar que ningún campo esté vacío
    var camposVacios = false;
    formData.forEach(function(value) {
        if (value.trim() === '') {
            camposVacios = true;
        }
    });

    if (camposVacios) {
        alertify.error("Por favor, completa todos los campos antes de enviar el formulario");
        return;
    }

    // Crear la solicitud AJAX
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "controllers/registro.php", true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                alertify.success(xhr.responseText);
                form.reset();
                window.location.href = "login.php";
            } else {
                alertify.error("Error al registrar usuario");
            }
        }
    };

    // Enviar la solicitud AJAX con los datos del formulario
    xhr.send(formData);
}

document.addEventListener('DOMContentLoaded', function () {
    // Puedes agregar aquí más lógica de JavaScript si es necesario
});