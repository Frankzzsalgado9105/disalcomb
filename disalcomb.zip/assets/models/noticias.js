document.addEventListener("DOMContentLoaded", function () {
    loadservices();
});

function registrarnoticia() {
    // Implementa la lógica para registrar un usuario usando AJAX y PHP
    var form = document.getElementById("marcaForm");
    var formData = new FormData(form);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "controller/save_services.php", true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alertify.success(xhr.responseText);
            form.reset();
        } else if (xhr.readyState === 4 && xhr.status !== 200) {
            alertify.error("Error al registrar usuario");
        }
    };
    xhr.send(formData);
}

document.addEventListener('DOMContentLoaded', function () {
    loadservices();// Puedes agregar aquí más lógica de JavaScript si es necesario
});
function loadservices() {
    // Realizar solicitud AJAX para obtener la lista de productos
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'controllers/vernoticias.php', true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Éxito: actualizar la lista de productos
            var noticestList = document.getElementById("noticias");
            noticestList.innerHTML = xhr.responseText;
        } else {
            console.error('Error al cargal la lista', xhr.status, xhr.statusText);
            // Mostrar mensaje de error con Alertify
            alertify.error('Error al cargar la lista de productos. Por favor, inténtelo de nuevo.');
        }
    };
    
    // Manejar errores de red
    xhr.onerror = function() {
        console.error('Error de red al intentar cargar la lista de productos');
        // Mostrar mensaje de error de red con Alertify
        alertify.error('Error de red al intentar cargar la lista de productos. Por favor, revise su conexión.');
    };

    xhr.send();
}
