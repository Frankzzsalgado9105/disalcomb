<?php
include "template/header.php";
?>
<?php
  include "hero.php";
  ?>

  <main id="main">
  <?php
  include "conocenos.php";
  include "nuevo.php";
  include "contactanos.php";
  ?>
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
  include "template/footer.php";
  ?>