<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="container text-center text-md-left" data-aos="fade-up">
      <img src="assets/img/dsclogo.png" width="200px" height="200px" alt="">
      <h2>TU GASOLINERA</h2>
      <a href="#about" class="btn-get-started scrollto">Conocenos</a>
    </div>
  </section><!-- End Hero -->