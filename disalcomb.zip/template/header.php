<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Gasolinera DSC</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Lumia
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/lumia-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <img src="assets/img/dsclogo.png" width="180px" height="120px" alt="">
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">INICIO</a></li>
          <li class="dropdown"><a href="#"><span>PRODUCTOS </span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li class="dropdown"><a href="#"><span>MARCAS</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">CEPSA</a></li>
                  <li><a href="#">VP RACING </a></li>
                  <li><a href="#">PETROKING</a></li>
                  <li><a href="#">XTRA GUARD</a></li>
                </ul>
              </li>
              <li class="dropdown"><a href="#"><span>CATEGORIAS</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li class="dropdown"><a href="#"><span>ADITIVOS</span> <i class="bi bi-chevron-right"></i></a>
                    <ul>
                      <li><a href="#">LIMPIEZA Y MANTENIMIENTO</a></li>
                      <li><a href="#">CARRETERAS Y ALTO RENDIMIENTO</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"><a href="#"><span>LUBRICANTES</span> <i class="bi bi-chevron-right"></i></a>
                    <ul>
                      <li class="dropdown"><a href="#"><span>MOTOR</span> <i class="bi bi-chevron-right"></i></a>
                        <ul>
                          <li><a href="#">PESADO</a></li>
                          <li><a href="#">LIVIANO</a></li>
                        </ul>
                      </li>
                      <li><a href="#">TRANSMICIONES</a></li>
                      <li><a href="#">GRASAS</a></li>
                      <li><a href="#">HIDRAULICOS</a></li>
                      <li><a href="#">INDUSTRIALES</a></li>
                      <li><a href="#">BICICLETAS</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>SERVICIOS</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">LUBRICENTROS</a></li>
              <li><a href="#">GASOLINERAS</a></li>
              <li><a href="#">COMBUSTIBLES</a></li>
              <li><a href="#">TIENDAS DE CONVENIENCIA</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>CONTACTO</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a class="nav-link scrollto" href="#contact">CONTACTENOS</a></li>
              <li><a href="#">SUCURSALES</a></li>
            </ul>
          </li>
          <li class="btn-get-started " ><a href="login.php" >INICIAR SESION</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <div class="header-social-links d-flex align-items-center">
        <h5><a href="#" class="facebook"><i class="fa-brands fa-facebook" style="color: #1877f2;"></i></a></h5>
        <h5><a href="#" class="instagram"><i class="fa-brands fa-instagram" style="color: #e1306c;"></i></a></h5>
        <h5><a href="#" class="linkedin"><i class="fa-brands fa-whatsapp" style="color: #25d366;"></i></a></h5>
        <h5><a href="#" class="linkedin"><i class="fa-regular fa-envelope" style="color: #ff0000;"></i></a></h5>
      </div>

    </div>
  </header><!-- End Header -->