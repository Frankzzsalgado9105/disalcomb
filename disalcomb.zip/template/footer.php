<footer id="footer" style="background: #0a0f66 ; color:#ffffff;">

  <div class="footer-top">
    <div class="container">
      <div class="row">

        <div class="col-lg-3 col-md-6 footer-contact">
          <img class="img-fluid" src="assets/logos/LogoDSC.png" width="200px" height="100px" alt="">
          <b>
            <h5>Disalcomb S.A de C.V</h5>
          </b>
        </div>

        <div class="col-lg-2 col-md-6 footer-links">
          <h4>Mapa de sitio</h4>
          <ul>
            <li><i class="bx bx-chevron-right"></i> <a href="#">Inicio</a></li>
            <li><i class="bx bx-chevron-right"></i> <a href="#">Conocenos</a></li>
            <li><i class="bx bx-chevron-right"></i> <a href="#">Nuestros servicios</a></li>
            <li><i class="bx bx-chevron-right"></i> <a href="#">Terminos y condiciones</a></li>
            <li><i class="bx bx-chevron-right"></i> <a href="#">Politicas de terceros</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-md-6 footer-newsletter">
          <h4>Disfruta de nuestros beneficios</h4>
          <form action="" method="post">
            <input type="email" name="email"><input type="submit" value="Suscribirse">
          </form>
        </div>

      </div>
    </div>
  </div>

  <div class="container d-md-flex py-4" >

    <div class="me-md-auto text-center text-md-start">
      <div class="copyright" >
        &copy; Copyright. Todos los derechos reservados. <strong><span>Disalcomb</span></strong>.
      </div>
    </div>
  </div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://kit.fontawesome.com/cd6693324c.js" crossorigin="anonymous"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>


<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>

</body>

</html>