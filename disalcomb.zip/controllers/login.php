<?php
include '../conexion/conect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoge los datos del formulario
    $correo = $_POST["correo"];
    $contrasena = hash('sha256', $_POST["contrasena"]);

    // Consulta SQL segura con consultas preparadas
    $sql = "SELECT correo_usuario, user_usuario, contrasena_usuario, nombre_usuario, tipo_usuario, id_usuario, estado_usuario FROM usuarios WHERE correo_usuario = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($correo_bd, $username_bd, $contrasena_bd, $nombre_bd, $tipo_bd, $id_bd, $stado_bd);
        $stmt->fetch();
        session_start();       
        $_SESSION['id'] = $id_bd;
        $_SESSION['correo'] = $correo_bd;
        $_SESSION['nombre'] = $nombre_bd;
        $_SESSION['tipouser'] = $tipo_bd;
        if ($stado_bd === 0) {
            $response = array('error' => false, 'message' => 'Su usuario no se encuentra activo. Favor comunicarse con soporte.');
        } else {
            // Verificar la contraseña utilizando password_verify
            IF ($contrasena === $contrasena_bd) {
       

                $response = array('success' => true, 'message' => 'Bienvenido a Disalcomb');
            } else {
                $response = array('error' => false, 'message' => 'Las credenciales ingresadas son incorrectas');
            }
        }
    } else {
        $response = array('error' => false, 'message' => 'El correo ingresado no está registrado');
    }

    // Devuelve la respuesta como JSON
    header('Content-Type: application/json');
    echo json_encode($response);

    $stmt->close();
    $mysqli->close();
} else {
   
    // Si no es una solicitud POST, redirige a la página de inicio
    header('Location: dashboard.php');
    exit();
}
?>
