<?php
include '../conexion/conect.php';
// Crear y ejecutar la consulta SQL para obtener la lista de productos
$sql = "SELECT * FROM notas";
$result = $mysqli->query($sql);

// Verificar si la consulta tuvo éxito
if ($result === false) {
    die("Error en la consulta SQL: " . $mysqli->error);
}
// Iniciar la tabla
echo "<div class='container'><table class='table table-responsive'>
        <tr>
            <th>Correlativo</th>
            <th>CNombre Noticia</th>
            <th>Descripcion</th>
            <th>Opciones</th>
        </tr>";

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Mostrar la lista de productos en la tabla
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id_nota"] . "</td>";
        echo "<td>" . $row["nombre_nota"] . "</td>";
        echo "<td>" . $row["descripcion_nota"] . "</td>";
        echo "<td><a class='btn btn-warning' href='detalles_servicio.php?id=" . $row["id_nota"] . "'><i class='fa-solid fa-pen-to-square'></i></a> | 
        <a class='btn btn-danger' href='detalles_servicio.php?id=" . $row["ss"] . "'><i class='fa-solid fa-trash'></i></a>
        </td>";
    }
} else {
    // Mostrar un mensaje si no hay productos
    echo "<tr><td colspan='6'>
    <div class='alert alert-success' role='alert'>
    No hay servicios disponibles
    </div>
</td></tr>";
}

// Cerrar la tabla y la conexión a la base de datos
echo "</table></div>";

// Cerrar la conexión a la base de datos
$mysqli->close();
?>