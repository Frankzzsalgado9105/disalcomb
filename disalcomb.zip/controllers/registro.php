<?php
include '../conexion/conect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreuser = $_POST['nombreuser'];
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $tipo = 2;
    $estado = 0;
    $password = hash('sha256', $_POST["contrasena"]);

    // Validar la entrada (ejemplo: verificar el formato del correo electrónico)
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        echo "Error: El formato del correo electrónico no es válido";
        exit();
    }

    // Verificar si el usuario ya existe en la base de datos
    $stmt_verificar = $mysqli->prepare("SELECT id_usuario FROM usuarios WHERE nombre_usuario = ? or correo_usuario = ?");
    $stmt_verificar->bind_param("ss", $nombreuser, $correo);
    $stmt_verificar->execute();
    $stmt_verificar->store_result();

    if ($stmt_verificar->num_rows > 0) {
        echo "Error: El nombre de usuario ya está en uso";
        exit();
    }

    $stmt_verificar->close();

    // Insertar el nuevo usuario si no hay conflictos
    $stmt_insertar = $mysqli->prepare("INSERT INTO usuarios (nombre_usuario, correo_usuario, contrasena_usuario, tipo_usuario, estado_usuario, user_usuario) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt_insertar->bind_param("ssssss", $nombre, $correo, $password, $tipo, $estado, $nombreuser);

    if ($stmt_insertar->execute()) {
        // Redirigir a la página de inicio de sesión después de guardar los datos
    } else {
        // Proporcionar información detallada sobre el error
        echo "Error al registrar usuario: " . $stmt_insertar->error;
    }

    $stmt_insertar->close();
}

$mysqli->close();
?>
